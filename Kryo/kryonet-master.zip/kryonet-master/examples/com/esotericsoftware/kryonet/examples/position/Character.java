
package com.esotericsoftware.kryonet.examples.position;

public class Character {
	public String name;
	public String otherStuff;
	public int id, x, y;
}
